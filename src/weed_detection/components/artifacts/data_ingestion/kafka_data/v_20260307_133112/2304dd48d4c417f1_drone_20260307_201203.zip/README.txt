Sample Dataset created on 2026-03-05 15:19:45
==================================================

Dataset Structure:
- train/: Contains training images and labels
- test/: Contains test images and labels

File Naming Convention:
- train_image_XXX.png: Training images
- train_label_XXX.txt: Corresponding labels for training images
- test_image_XXX.png: Test images
- test_label_XXX.txt: Corresponding labels for test images

Label File Format:
Each label file contains:
- Object type
- Shape information
- Associated image filename
- Description

Statistics:
- Training samples: 10
- Test samples: 5
